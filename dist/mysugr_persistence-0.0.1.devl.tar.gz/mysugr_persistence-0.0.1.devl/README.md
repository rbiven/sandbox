# mySugr Persistence Package

This package will allow for connection to the mySugr databases with a few simple commands.

Simply install the package with `<pip install GITHUB URL TBD>`.

